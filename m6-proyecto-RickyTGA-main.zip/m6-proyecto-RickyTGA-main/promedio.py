""" TODO#1 Aqui """

def calcular_promedio(lista):
    # TODO 2: Completa esta función para devolver el promedio
    pass

def contar_mayores_que(lista, valor):
    # TODO 3: Cuenta cuántos elementos en la lista son mayores que 'valor'
    pass

def main():
    entrada = input("Ingresa calificaciones separadas por comas: ")
    
    # TODO 4: Convierte la entrada en una lista de enteros
    calificaciones = []

    # TODO 5: Llama a las funciones necesarias y muestra:
    # - El promedio
    # - La nota más alta
    # - La nota más baja
    # - Cuántas están por encima del promedio

if __name__ == "__main__":
    main()

# Salida esperada:
# Ingresa calificaciones separadas por comas: 75, 80, 90, 60, 100

# Promedio: 81.0
# Nota más alta: 100
# Nota más baja: 60
# Calificaciones por encima del promedio: 2