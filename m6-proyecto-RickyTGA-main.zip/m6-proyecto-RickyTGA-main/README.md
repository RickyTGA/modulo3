[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/B_187lN3)
# C1400-O25-M6
Esta semana trabajaremos en tres programas diferentes. Cada uno tiene su propio objetivo y te ayudará a practicar conceptos importantes de programación en Python.

---

## 1. Verificador de letras en palabras

**Objetivo:**  
Escribir funciones que analicen una palabra para verificar si:
- No contiene letras prohibidas
- Solo contiene letras permitidas
- Contiene todas las letras requeridas

**Funciones a completar:**

- `ninguno(palabra, prohibidas)`: Devuelve `True` si la palabra **no contiene ninguna** letra prohibida.
- `unicamente(palabra, permitidas)`: Devuelve `True` si la palabra **solo contiene** letras permitidas.
- `todas(palabra, requerido)`: Ya está implementada, revisa si la palabra contiene todas las letras requeridas.

**Cómo usar:**
Ejecuta el programa, ingresa una palabra y observa los resultados para las tres funciones.

---

## 2. Verificador de ortografía en inglés

**Objetivo:**  
Crear un programa que reciba una lista de palabras escritas por el usuario y las compare con una lista de palabras correctas en inglés.

**Tareas a completar:**

- Crear una lista vacía `errores` para almacenar las palabras incorrectas.
- Convertir la entrada del usuario en una lista limpia (sin espacios y en minúsculas).
- Mostrar las palabras que están mal escritas y el número total de errores.

**Cómo usar:**
Ejecuta el programa y escribe las palabras para “gato, perro, casa y árbol” en inglés, separadas por comas. El programa indicará cuáles están mal escritas.

---

## 3. Estadísticas de calificaciones

**Objetivo:**  
Procesar una lista de calificaciones y calcular:

- El promedio
- La nota más alta
- La nota más baja
- Cuántas calificaciones están por encima del promedio

**Funciones a completar:**

- `calcular_promedio(lista)`: Devuelve el promedio de las calificaciones.
- `contar_mayores_que(lista, valor)`: Cuenta cuántos valores en la lista son mayores que un valor dado.
- Convertir la entrada en una lista de enteros.
- Mostrar todos los resultados calculados.

**Cómo usar:**
Ejecuta el programa, ingresa las calificaciones separadas por comas y observa las estadísticas.

---

## Recomendaciones generales

- Lee cada función y comentario para entender qué debes completar.
- Prueba con diferentes datos para verificar que tus funciones funcionan correctamente.
- Pregunta si tienes dudas en clase o en el foro.

---