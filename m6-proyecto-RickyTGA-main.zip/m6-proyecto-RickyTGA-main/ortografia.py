# TODO #1: Agregar comentario que describe cual es el punto de este programa

#Pedir al usuario 
def verificar_ortografia(palabras_usuario, palabras_correctas):
    #TODO #2: Agrega una línea que cree una lista vacía
    #  llamada errores. Esta lista se usará para guardar las
    #  palabras que el usuario escribió incorrectamente.
    

    for palabra in palabras_usuario:
        if palabra not in palabras_correctas:
            errores.append(palabra)
    return errores  # Devuelve la lista de palabras con errores


def main():
    print("Bienvenido al verificador de ortografía.")
    ###Aqui sirve con un compañero para reemplazar las palabras
    print("Escribe en ingles la palabra para: gato, perro, casa, y arbol, separadas por comas (sin tildes).")
    entrada = input("Palabras: ")

    # TODO #3: Convierte entrada en una lista de palabras
    #  (minúsculas, sin espacios)
    #PISTA: De usar lower replace y split
    

    # La lista de palabras correctamente escritas
    palabras_correctas = ["cat", "dog", "house", "tree"]

    errores = verificar_ortografia(palabras_usuario, palabras_correctas)
    
    if len(errores) == 0:
        print("¡Todas tus palabras están escritas correctamente!")
    else:
        print("Palabras con errores ortográficos:")
        # TODO #3: Usa un bucle for que imprime 
        # cada palabra que tiene un error y lo imprima con un mensaje de cuantos errores hay.

# Llamamos a la función principal
if __name__ == "__main__":
    main()
