
"""
El propósito de este programa es verificar si una palabra cumple ciertas condiciones respecto 
al uso de letras, como evitar letras prohibidas,usar solo letras permitidas, o contener todas las letras
requeridas.
"""

def ninguno(palabra, prohibidas):
    """
    Devuelve True si ninguna letra prohibida está presente en la palabra.
    """
    # TODO #1: Completa esta función
    pass


def unicamente(palabra, permitidas):
    """
    Devuelve True si la palabra solo contiene letras en la cadena de permitidas.
    """
    # TODO #2: Completa esta función
    pass


def todas(palabra, requerido):
    """
    Revisa si una palabra utiliza todas las letras requeridas al menos una vez.
    """
    for letra in requerido:
        if letra not in palabra:
            return False
    return True


def main():
    # Obtener una palabra del usuario
    palabra = input("Ingresa la palabra a analizar: ").strip().lower()    #por ejemplo, bacalao, cabana deben pasar y examen, zooro deben fallar.

    # Puedes definir algunos ejemplos para probar aquí
    letras_prohibidas = "xyz"
    letras_permitidas = "abcdefghijklmnñopqrstuvwxyz"
    letras_requeridas = "abc"

    print("¿Ninguna letra prohibida?", ninguno(palabra, letras_prohibidas))
    print("¿Solo letras permitidas?", unicamente(palabra, letras_permitidas))
    print("¿Contiene todas las letras requeridas?", todas(palabra, letras_requeridas))


# Esta línea permite que el script se ejecute directamente, pero no al importarse como módulo.
if __name__ == "__main__":
    main()
