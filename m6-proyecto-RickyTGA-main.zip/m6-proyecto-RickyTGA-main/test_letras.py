# test_letras.py

# Asegúrate de que el archivo principal se llame letras.py o cambia el nombre aquí
from letras import ninguno, unicamente, todas

def test_ninguno():
    assert ninguno("hola", "xyz") == True, "Debe ser True: 'hola' no contiene 'x', 'y', ni 'z'"
    assert ninguno("extraño", "xyz") == False, "Debe ser False: 'extraño' contiene 'x'"
    assert ninguno("feliz", "z") == False, "Debe ser False: 'feliz' contiene 'z'"
    assert ninguno("mundo", "") == True, "Debe ser True: sin letras prohibidas"

def test_unicamente():
    assert unicamente("hola", "abcdefghijklmnopqrstuvwxyzñ") == True, "Debe ser True: todas las letras permitidas"
    assert unicamente("hola123", "abcdefghijklmnopqrstuvwxyz") == False, "Debe ser False: contiene números"
    assert unicamente("aabbcc", "abc") == True, "Debe ser True: solo usa 'a', 'b', 'c'"
    assert unicamente("árbol", "abcdefghijklmnopqrstuvwxyz") == False, "Debe ser False: contiene tilde"

def test_todas():
    assert todas("murcielago", "aeiou") == True, "Debe ser True: contiene todas las vocales"
    assert todas("pingüino", "aeiou") == False, "Debe ser False: falta 'a'"
    assert todas("libro", "or") == True, "Debe ser True: contiene 'o' y 'r'"
    assert todas("verde", "") == True, "Debe ser True: no se requiere ninguna letra"